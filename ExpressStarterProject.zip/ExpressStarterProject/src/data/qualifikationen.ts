export const qualifikationen: string[] = [
  "Reinigung",
  "Transport",
  "Koordination",
  "Sicherheit"
];
