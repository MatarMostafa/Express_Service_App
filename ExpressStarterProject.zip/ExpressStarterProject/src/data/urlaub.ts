import { Urlaub } from "../types/urlaub";

export const urlaube: Urlaub[] = [
  {
    id: 1,
    mitarbeiterId: 1,
    von: "2025-08-10",
    bis: "2025-08-20",
    grund: "Sommerurlaub",
    status: "genehmigt",
    erstelltAm: "2025-07-15"
  }
];