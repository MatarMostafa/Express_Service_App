export interface AuftragQualifikation {
  auftragId: number;
  qualifikationId: number;
}

export const auftragQualifikationen: AuftragQualifikation[] = [
  { auftragId: 1, qualifikationId: 1 },
  { auftragId: 2, qualifikationId: 2 },
];