// src/data/gesperrteMitarbeiter.ts

export const gesperrteMitarbeiter: number[] = []; // Array mit Mitarbeiter-IDs