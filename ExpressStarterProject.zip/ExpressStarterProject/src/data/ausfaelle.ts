// src/data/ausfaelle.ts

export const gesperrteMitarbeiter: number[] = []; // speichert IDs