import { Mitarbeiter } from '../types/mitarbeiter';

export const mitarbeiterData: Mitarbeiter[] = [
  {
    id: 1,
    name: 'Max Mustermann',
    rolle: 'admin',
    aktiv: true
  },
  {
    id: 2,
    name: 'Erika Musterfrau',
    rolle: 'teamleiter',
    aktiv: true
  },
  {
    id: 3,
    name: 'John Doe',
    rolle: 'mitarbeiter',
    aktiv: true
  }
];
