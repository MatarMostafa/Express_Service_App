export function sendePushBenachrichtigung(mitarbeiterId: string, nachricht: string) {
  console.log(`📲 Push an ${mitarbeiterId}: ${nachricht}`);
}