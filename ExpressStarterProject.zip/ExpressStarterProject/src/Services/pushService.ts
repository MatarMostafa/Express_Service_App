// Einheitliche Push-Service-Datei

interface Subscription {
  endpoint: string;
  keys: {
    p256dh: string;
    auth: string;
  };
}

let subscriptions: Subscription[] = [];

/**
 * Speichert eine neue Subscription
 */
export const saveSubscription = (sub: Subscription) => {
  subscriptions.push(sub);
};

/**
 * Sendet eine einfache Push-Benachrichtigung (Simulation)
 */
export const sendPushNotification = async (title: string, message: string) => {
  console.log(`[Push] ${title}: ${message}`);
  // Hier könntest du mit web-push echte Nachrichten senden
};

/**
 * Sendet Push an einen bestimmten User
 */
export const sendPush = (userId: string, message: string) => {
  console.log(`📲 PUSH an ${userId}: ${message}`);
};
